package Project1;

import java.sql.Connection;

public interface EmpService {
	Connection dbConnect();

}
